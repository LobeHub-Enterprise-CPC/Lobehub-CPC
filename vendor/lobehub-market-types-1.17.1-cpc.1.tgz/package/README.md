# LobeHub Market Types

[![NPM version](https://img.shields.io/npm/v/@lobehub/market-sdk.svg?style=flat)](https://npmjs.org/package/@lobehub/market-types)
[![NPM downloads](https://img.shields.io/npm/dm/@lobehub/market-sdk.svg?style=flat)](https://npmjs.org/package/@lobehub/market-types)

This package contains TypeScript type definitions for the LobeHub Market ecosystem. It provides a comprehensive set of interfaces and type definitions that are shared between the API server and client applications.

## Overview

The type definitions in this package are organized into the following categories:

- **Market Base Types**: Common type definitions used across all marketplace items
- **Plugin Types**: Types related to plugins, their capabilities, and deployment options
- **Agent Types**: Types related to AI agents and their features

## Installation

```bash
npm install @lobehub/market-types
# or
yarn add @lobehub/market-types
# or
pnpm add @lobehub/market-types
```

## Usage

Import the types you need in your TypeScript files:

```typescript
import { AgentItem, MarketItemBase, PluginManifest } from '@lobehub/market-types';

// Use the types in your code
const plugin: PluginManifest = {
  id: 'my-plugin',
  name: 'My Plugin',
  description: 'A sample plugin',
  version: '1.0.0',
  // ...other properties
};
```

## Type Categories

### Market Base Types

The `MarketItemBase` interface defines the common properties shared by all marketplace items:

```typescript
interface MarketItemBase {
  author?: string;
  category?: string;
  description: string;
  identifier: string;
  name: string;
  // ...other properties
}
```

### Plugin Types

Plugin-related types include:

- `PluginManifest`: Complete specification of a plugin
- `PluginTool`: Definition of a tool provided by a plugin
- `PluginPrompt`: Definition of a prompt template
- `PluginResource`: Definition of a resource provided by a plugin
- `DeploymentOption`: Deployment configuration for a plugin

### Agent Types

Agent-related types include:

- `AgentItem`: Definition of an agent in the marketplace

## Structure

```
src/
├── market.ts       - Base marketplace item types
├── agent/          - Agent-related types
│   └── index.ts    - Agent type definitions
├── plugin/         - Plugin-related types
│   ├── admin.ts    - Admin-specific plugin types
│   ├── capabilities.ts - Plugin capability types
│   ├── deploymentOption.ts - Deployment option types
│   ├── plugin.ts   - Core plugin types
│   └── index.ts    - Plugin exports
└── index.ts        - Package exports
```

## Development

To build the package:

```bash
pnpm build
```

## License

MIT
